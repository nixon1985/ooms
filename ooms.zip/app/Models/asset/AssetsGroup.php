<?php

namespace App\Models\asset;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetsGroup extends Model
{
    use HasFactory;
    protected $table="asset_group";
}
