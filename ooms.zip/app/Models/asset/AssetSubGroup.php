<?php

namespace App\Models\asset;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetSubGroup extends Model
{
    use HasFactory;
    protected $table="asset_sub_group";
}
