Some image(s) are beautiful illustrations used in templates, is a wonderful work of:

* [UI Faces](https://uifaces.co/)
* [404 illustration](https://www.freepik.com/free-vector/404-error-design-with-space_1535242.htm)
* [Undraw](https://undraw.co)
* [Photo by Venveo on Unsplash](https://unsplash.com/photos/qY9zgRqmNtA)
* [Photo by Alex Kotliarskyi on Unsplash](https://unsplash.com/photos/QBpZGqEMsKg)
* [Photo by Natalya Letunova on Unsplash](https://unsplash.com/photos/XwrPo8MWUGQ)
